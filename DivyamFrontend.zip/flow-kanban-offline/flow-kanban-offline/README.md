# Flow Automate Kanban - Offline Version

This version works without npm, React, or Vite.

## How to run
Just open `index.html` in any browser.

## Features
- 3 columns: To Do, In Progress, Done
- Drag and drop
- Optimistic UI update
- Mock API delay: 1.5 seconds
- 20% random failure
- Rollback on failure
- Toast notifications
